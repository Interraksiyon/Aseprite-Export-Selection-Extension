# Contributing

Thank you for contributing to Quick Export Selection, maintained by Interaksiyon.
Issues and pull requests are welcome. Keep changes focused and explain the
behavior that changes for someone using the extension.

## Project layout

```text
main.lua                 Aseprite command, dialog, and export logic
package.json             Extension metadata
LICENSE                  MIT license and copyright notice
build.ps1                Extension and clean source packages
test.ps1                 Local Aseprite test runner
scripts/check.ps1        Metadata, formatting, and package checks
scripts/source-files.ps1 Source distribution file list
tests/integration.lua    Tests using real Aseprite sprites and encoders
.github/                 CI, issue forms, and pull request template
```

Keep the extension self-contained in `main.lua`. Build and test tools belong
outside the installed extension. Use the formatting in [.editorconfig](.editorconfig):
UTF-8, LF line endings, two spaces for Lua, and four spaces for PowerShell.
When adding project files, update `scripts/source-files.ps1` to include them in
the source distribution.

## Validate and build

In a PowerShell terminal at the repository root:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\check.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File .\build.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\check.ps1 -Packages
```

If Lua 5.4 is installed, check syntax with:

```text
luac -p main.lua
luac -p tests/integration.lua
```

GitHub Actions performs these syntax checks automatically, along with repository
and package validation. It uses read-only repository permissions and uploads
build artifacts without publishing a release.

## Aseprite integration tests

Use your own Aseprite installation; Aseprite is not bundled or fetched by CI.
The Windows runner automatically checks PATH and common installation locations,
or accepts an explicit path:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\test.ps1 -AsepritePath 'C:\Program Files (x86)\Steam\steamapps\common\Aseprite\Aseprite.exe'
```

Normal exports use real sprites and encoders with simulated dialog input.
Failure conditions are injected to exercise write and replacement errors.
They cover frame selection, visibility, timing, color modes, cancellation,
validation, document preservation, and failed writes and file replacements.
They do not exercise the visual dialog or extension installation.

Successful runs clean up their generated configuration and output directories.
Failed runs keep their files for inspection. To retain a successful run, add
`-KeepArtifacts` to the command.

For GUI changes, also install the generated extension, open a sprite, make a
selection, and check the menu command, file picker, Save/Cancel buttons, and
keyboard shortcut in Aseprite. Report the operating system and Aseprite version
used for validation in your pull request.

## Report a problem

Include the extension and Aseprite versions, operating system, export format,
steps to reproduce, and the error message or unexpected output. Attach a small
sample sprite if it helps and you have permission to share it.

## Prepare a release

1. Update `version` in `package.json`, the package examples in README, and
   [CHANGELOG.md](CHANGELOG.md).
2. Run the repository checks, integration tests, build, and package checks above.
3. Commit the source files and create a tag matching the version, such as `v1.1.0`.
4. Create a GitHub Release for that tag. Attach the `.aseprite-extension`,
   `-source.zip`, and `SHA256SUMS.txt` from `dist/`.
5. Use the corresponding changelog entry as the release description.

The source ZIP is suitable for an initial GitHub upload: extract it and upload
its project files, including the `.github` directory. Keep `dist/` and generated
test directories out of the repository. The release checksum file uses the
standard `SHA256  filename` format.

## License

Contributions to this project are distributed under its [MIT License](LICENSE).
Retain the Interaksiyon copyright notice and add appropriate notices for any
new third-party code you introduce.

## Aseprite API references

- [Plugin registration](https://www.aseprite.org/api/plugin/)
- [Sprite API](https://www.aseprite.org/api/sprite/)
- [Dialog API](https://www.aseprite.org/api/dialog/)
- [Filesystem API](https://www.aseprite.org/api/app_fs/)
