# Quick Export Selection

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
![Aseprite 1.3+](https://img.shields.io/badge/Aseprite-1.3%2B-orange.svg)
![Lua](https://img.shields.io/badge/Built_with-Lua-2C2D72.svg)

**An open-source Aseprite extension by Interaksiyon.** Select an area, choose an
output file, and export it without changing your original sprite.

- Export the active frame as **PNG or JPEG**, or the full animation as **GIF**.
- Keep visible layers, frame timing, and supported transparency in the output.
- Open the export dialog from the menu or your own keyboard shortcut.
- Remember the last export folder and confirm before replacing an existing file.

## Install

Requires **Aseprite 1.3 or later** with Lua scripting support.

1. Download the `.aseprite-extension` package from this repository's **Releases**
   page, or [build it from source](#build-from-source).
2. In Aseprite, open **Edit > Preferences > Extensions > Add Extension** and
   select the package.
3. Confirm installation or replacement of an older version. Ensure the extension
   is enabled, then restart Aseprite if the command does not appear.

The current package is `quick-export-selection-1.1.0.aseprite-extension`.
Updating retains the command ID used by existing keyboard shortcuts.

## Use

1. Open a sprite and select an area with a selection tool.
2. Choose **File > Export > Export Selection**.
3. Choose a file name and destination, then click **Save**. A missing extension
   defaults to `.png`.

For a shortcut, open **Edit > Keyboard Shortcuts > Commands**, find
**Export Selection**, and assign an available key combination.

| Format | Frames | Transparency |
| --- | --- | --- |
| PNG | Active frame | Preserved |
| JPG / JPEG | Active frame | Not supported by JPEG |
| GIF | All frames, with their durations | Limited to GIF's supported transparency and colors |

### Selection behavior

The output is cropped to the **rectangle surrounding the selection**, clipped
to the canvas. For lasso, magic-wand, or disconnected selections, unselected
pixels inside that rectangle are included. This is a rectangular crop rather
than a pixel mask.

The original document, selection, active layer, frame, color mode, and undo
history are preserved. PNG and JPEG produce one image instead of an unintended
frame sequence. Indexed sprites are converted for JPEG, and grayscale sprites
for GIF, using the temporary copy.

Exports are written to a temporary file in the destination folder and read back
to verify that they open with the expected dimensions before being moved into
place. When replacing a file, its previous contents are kept in a
backup until the replacement succeeds. Normal completion removes the temporary
files. If Aseprite or the computer stops during an export, a `.quick-export-*`
file may remain in that folder; a `.bak` file contains the previous output.

## Troubleshooting

| Issue | What to check |
| --- | --- |
| Command is missing | Enable the extension in Preferences and restart Aseprite. |
| Command is disabled | Open a sprite and select an area that overlaps the canvas. |
| Export fails | Choose an existing, writable folder and a supported extension. |
| Shortcut does not work | Confirm its assignment and check for conflicts in Keyboard Shortcuts. |
| JPEG loses transparency or GIF changes colors | Use PNG when those format limits are unsuitable. |

## Build from source

From the repository folder, run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\build.ps1
```

PowerShell 5.1 or later is sufficient. No npm or Lua packages are needed for
building. The build validates metadata, includes the MIT license, and creates:

```text
dist/quick-export-selection-1.1.0.aseprite-extension
dist/quick-export-selection-1.1.0-source.zip
dist/SHA256SUMS.txt
```

The source ZIP contains only project files. Generated packages and test caches
are excluded from version control.

## Development

Read [CONTRIBUTING.md](CONTRIBUTING.md) for source checks, Aseprite integration
tests, and the release process. See [CHANGELOG.md](CHANGELOG.md) for changes.

GitHub Actions checks Lua syntax, validates the repository, builds the packages,
and verifies their contents. Integration tests run locally with your installed
Aseprite; the workflow does not distribute or download Aseprite.

Tested on **Windows with Aseprite 1.3.18.6**. The Lua extension uses Aseprite's
cross-platform APIs; macOS and Linux GUI behavior has not been verified here.
Reports and contributions from those platforms are welcome.

## License

**Copyright (c) 2026 Interaksiyon.** Released as open-source software under the
[MIT License](LICENSE). You may use, modify, and redistribute this project,
including commercially, while retaining the copyright and license notice.

Aseprite is a separate application and is not included in this project.
